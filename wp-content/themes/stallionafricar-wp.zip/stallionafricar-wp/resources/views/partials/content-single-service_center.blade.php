<div id="customPage"  class="inherit py-10 bg-background" style="top: 0">
  <div class="custom-page-container">
    <div class="container">
      <h2>@php the_title() @endphp</h2>
    </div>
    <div class="container relative">
      <div class="content">
        @php the_content() @endphp
      </div>
    </div>
  </div>
</div>