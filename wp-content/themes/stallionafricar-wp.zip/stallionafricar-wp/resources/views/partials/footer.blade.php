<footer class="content-info bg-black">
  <div class="container flex justify-center items-center h-full">
    <div class="w-full text-center">
      <p class="text-white text-sm">Copyrights &copy; <?= date('Y'); ?>. All Rights Reserved.</p>
    </div>
  </div>
</footer>
